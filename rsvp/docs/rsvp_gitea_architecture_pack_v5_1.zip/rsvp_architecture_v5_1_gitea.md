
# RSVP Micro‑Site — Architecture Document (v5.1, **Gitea‑first CI/CD**)

_Last updated: 2025‑10‑01_

## Changelog (v5.1 vs v5.0/v5)
- **CI/CD defaults to Gitea Actions** with a self‑hosted runner on Proxmox; GitHub Actions documented as a **future/alternate** profile.
- Added a first‑class **Gitea Container Registry** path and SSH deploy to self‑host.
- Clarified workflow layout (`.gitea/workflows/`), runner labels, secrets, and environment promotion.
- Included migration notes to GitHub (workflows, registry, OIDC), keeping all other stack decisions from v5 intact.
- Folded in prior v5 polish: k6 load tests, Playwright + axe, dietary MV refresh jobs, session eviction, CDN purge + Next revalidate, recovery‑codes UX, etc.

> Everything from v4/v5 (self‑hosted Proxmox + Cloudflare Tunnel, Postgres/Redis, security, jobs, scaling) **still applies**; this version focuses on **how we build and ship**.

---

## 1) System Overview (unchanged)
- **App**: Next.js 15 monolith (SSR + API Route handlers), Node 20, TypeScript.
- **Data**: PostgreSQL 14+ (JSONB, strict CHECKs), Redis 7 (rate limits, jobs).
- **Edge**: Cloudflare DNS/CDN/WAF/TLS + Tunnel; Access on `/rsvp/admin/*`; Turnstile on public RSVP form.
- **Background**: BullMQ (reminders, digest, dietary MV refresh, audit purge, capacity alerts).
- **Observability**: pino JSON logs, OTEL traces + custom spans, optional Prometheus metrics.
- **Schema**: `rsvp_schema_v5_2.sql` (with admin recovery codes).

---

## 2) CI/CD — Gitea‑first

### 2.1 Workflows
- **Location**: `.gitea/workflows/*.yml`
- **Primary jobs**:
  1. **lint_typecheck** — Node 20 + pnpm cache; ESLint/TS.
  2. **unit_tests** — vitest/jest.
  3. **e2e_playwright** — spins up Postgres/Redis as services; Drizzle migrations; Playwright + axe checks.
  4. **k6_load** _(manual/dispatch)_ — runs duplicate‑heavy RSVP bursts against preview/prod URL.
  5. **deploy_selfhost** _(tagged releases)_ — build & push image to **Gitea Registry**, SSH into Proxmox VM, `docker compose pull && up -d`, run migrations, health‑check.

**Triggers**
- PRs/branch pushes → CI (lint, typecheck, unit, e2e).
- Tags `v*.*.*` → build & deploy.
- Manual `workflow_dispatch` → k6 load.

### 2.2 Runner
- **Runner**: `act_runner` installed on the Proxmox VM that also hosts the app (or a separate CI VM).
- **Labels**: use a custom label like `proxmox` and map common images if desired.
- **Capacity**: start with capacity=2; scale based on job duration and VM headroom.
- **Isolation**: Docker mode (default). If running on the same host as production containers, ensure different Docker networks and resource limits.

### 2.3 Registry & Artifacts
- **Images**: `gitea.example.com/<owner>/<image>:<tag>` (built on CI, stored in Gitea Container Registry).
- **App pulls** images by tag on deploy; rollback = redeploy previous tag.
- **SBOM/attestations**: optional follow‑up (Syft/Cosign) if supply‑chain hardening is needed.

### 2.4 Secrets
Repository (or organization) secrets used by workflows:
- `REGISTRY_HOST`, `REGISTRY_IMAGE`, `REGISTRY_USERNAME`, `REGISTRY_PASSWORD`
- `SSH_HOST`, `SSH_USER`, `SSH_PORT`, `SSH_PRIVATE_KEY`
- Optional: `RSVP_URL` for k6.

### 2.5 Environments & Promotion
- **Envs**: `dev` (optional), `staging` (ephemeral or long‑lived), `prod` (Proxmox VM behind Cloudflare Tunnel).
- **Promotion**: tag‑based releases (e.g., `v1.3.0`) deploy to prod. Staging can auto‑deploy on `main` success.
- **Approvals**: leverage Gitea branch protections + required status checks; add manual `workflow_dispatch` gates if desired.

### 2.6 Example Files (already provided as a starter pack)
- `.gitea/workflows/ci.yml`: CI pipeline with E2E and services.
- `.gitea/workflows/deploy-selfhost.yml`: build/push + SSH deploy + migrate.
- `load-test.js`: k6 scenarios (burst, mixed, duplicate‑heavy).
- `runner.config.yaml`: act_runner baseline config.
- `README-gitea-cicd.md`: runner registration + systemd service how‑to.

> When referencing marketplace actions, use **absolute URLs** (Gitea supports them) or mirror actions internally.

---

## 3) Deployment (Self‑hosted path)
- **Proxmox VM** (Debian 12): Docker Compose stack for app + Postgres + Redis; `cloudflared` Tunnel; Cloudflare Access; Turnstile.
- **Deploy step**: SSH in CI → `docker compose pull && up -d` → **Drizzle migration** → health check `/rsvp/healthz` (fail the job on non‑2xx).
- **CDN Purge** + **Next revalidation**: API handler for PATCHing events calls Cloudflare `purge_cache` (URL) and `revalidateTag('event:'+slug)`.
- **Backups**: nightly `pg_dump` to R2/B2 (7–30d lifecycle), weekly restore drill.

---

## 4) Rollback & Migrations
- **Code**: redeploy previous image tag (images remain in Gitea Registry).
- **Schema**: forward‑compatible pattern; `drizzle:push` for upgrades, `drizzle:revert` for hotfix rollbacks (keep a manual SQL fallback in CI artifacts).
- **Feature flags**: keep new code paths dark until healthy in staging.

---

## 5) Quality Gates (CI)
- **Lint + typecheck** must pass.
- **Unit** must pass; **E2E** green on staging build.
- **axe**: block on “critical” violations, warn on “serious”.
- **k6 (manual)** before large events or schema changes.
- **SLO watch**: fail build if server bundle size or page TTI regresses beyond budget (optional, using Lighthouse CI).

---

## 6) Observability (recap)
- **OTEL custom spans**: `rsvp.submit`, `capacity.check` (with `lock_wait_ms`), `dup.check`.
- **Metrics**: RSVP lock histogram, duplicates counter, **waitlist_length** (push on status change; optional pull `/metrics` fallback with 30s cache).
- **Alerts**: HighRPS (>400 rps 5m), high lock waits p95 (>2s 5m), dietary MV refresh failures, HIBP skip spikes, backup failures.

---

## 7) Security (recap + CI notes)
- **Admin 2FA** with hashed recovery codes (modal flow; CSV/print/QR; shown once).
- **Passwords**: argon2id + optional HIBP k‑anon check (rate‑limited; degrade banner + email if provider down).
- **CI secrets**: use PAT for registry; limit runner filesystem access; avoid mounting the Docker socket into production app containers.
- **Dependencies**: Dependabot‑equivalent in Gitea (Forgejo has native options; otherwise schedule `npm audit` reports).

---

## 8) Alternate/Future CI/CD — GitHub Actions
If/when you move to GitHub, keep the job architecture identical and adjust only the integrations:

**Workflow paths & marketplace**
- Move YAML to `.github/workflows/`.
- Use `actions/checkout@v4`, `actions/setup-node@v4` (without absolute URLs).

**Runners**
- Start with GitHub‑hosted runners; add self‑hosted if needed.
- Service containers work similarly for Postgres/Redis.

**Registry**
- Publish to **GHCR** (`ghcr.io/<owner>/<image>:<tag>`); use `GITHUB_TOKEN` (package:write) or PAT.
- Optionally keep Gitea Registry as a mirror.

**Cloud credentials**
- Prefer **OIDC** with cloud providers for deploy steps (no long‑lived keys).

**Secrets/Envs**
- Map Gitea secrets 1:1 to GitHub repo/environment secrets.

**CDN purge & revalidate**
- Same code path—only API credentials differ.

**Migration checklist**
1) Mirror repo to GitHub.  
2) Move workflow files to `.github/workflows`.  
3) Swap registry/push login and secret names.  
4) Validate Playwright service setup and k6 Action versions.  
5) Dry run on a staging stack; then cut over tags to deploy prod.

---

## 9) ADRs (Decision Records)
- **ADR‑006**: Choose **Gitea Actions** as primary CI/CD with a self‑hosted Proxmox runner and Gitea Container Registry; GitHub Actions remains a compatible alternate.
- **ADR‑007**: Continue **tag‑based deploys** to prod; staging auto‑deploys on `main` success.
- **ADR‑008**: Keep **Next.js monolith** with BullMQ worker in the same repo; split to API/worker services when sustained >500 rps (Prometheus alert at 400 rps).
- **ADR‑009**: Use **Cloudflare** for edge + Tunnel; purge by URL and `revalidateTag` after content mutations.

---

## 10) References & Artifacts
- **DDL**: `rsvp_schema_v5_2.sql`
- **Architecture**: v5 (self‑hosted + polish), this doc v5.1 (Gitea‑first CI/CD)
- **Gitea CI pack**: `.gitea/workflows/ci.yml`, `.gitea/workflows/deploy-selfhost.yml`, `load-test.js`, `runner.config.yaml`, `README-gitea-cicd.md`
