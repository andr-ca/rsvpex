import http from 'k6/http';
import { check, sleep } from 'k6';
export const options = {
  scenarios: {
    burst: { executor: 'constant-arrival-rate', rate: 80, timeUnit: '1s', duration: '60s' },
    mixed: { executor: 'constant-arrival-rate', rate: 200, timeUnit: '1s', duration: '60s', startTime: '65s' },
    dupes: { executor: 'constant-arrival-rate', rate: 80, timeUnit: '1s', duration: '30s', startTime: '130s' },
  },
  thresholds: {
    http_req_duration: ['p(95)<500'],
    'checks{kind:rsvp}': ['rate>0.99'],
  },
};
const rsvpUrl = __ENV.RSVP_URL;
export default function () {
  const d = Math.random();
  const payload =
    d < 0.2 ? { name: 'Alex Smith', email: 'dup@example.com', adults: 1 } :
    d < 0.3 ? { name: 'Alex Smith', phone: '+15555550100', adults: 1 } :
    { name: `U${Math.random().toString(36).slice(2,7)}`, email: `u${Date.now()}@x.tld`, adults: 1 };
  const res = http.post(rsvpUrl, JSON.stringify(payload), { headers: { 'Content-Type': 'application/json' } });
  check(res, { 'status ok or dup': (r) => [200,201,409,422].includes(r.status) }, { kind: 'rsvp' });
  sleep(0.1);
}
