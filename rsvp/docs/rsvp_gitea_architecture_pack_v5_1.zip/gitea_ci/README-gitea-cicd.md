# Gitea CI/CD (Self‑hosted, Proxmox runner)
## What you get
- `.gitea/workflows/ci.yml`: lint, typecheck, unit, e2e (Postgres+Redis), optional k6.
- `.gitea/workflows/deploy-selfhost.yml`: build/push to **Gitea Registry** + SSH deploy.
- `load-test.js`: k6 script with duplicate-heavy traffic.
- `runner.config.yaml`: sample `act_runner` config.
## Quick start
1) Enable Actions on your repo; install `act_runner` on Proxmox and register a runner.
2) Add repo secrets:
   - `REGISTRY_HOST`, `REGISTRY_IMAGE`, `REGISTRY_USERNAME`, `REGISTRY_PASSWORD`
   - `SSH_HOST`, `SSH_USER`, `SSH_PORT`, `SSH_PRIVATE_KEY`
   - optional: `RSVP_URL` for k6
3) Push these files; watch the Actions tab.
